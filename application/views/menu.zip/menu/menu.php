<main>
    <div class="container-fluid">
        <h1 class="mt-4">Daftar Menu</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo site_url('dashboard'); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Menu</li>
        </ol>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-concierge-bell mr-1"></i>
                Daftar Menu
                <a href="<?php echo site_url(); ?>/menu/tambah" class="btn btn-primary float-right"><i class="fas fa-plus mr-2"></i>Tambah Menu</a>
            </div>
            <div class="card-body">

                <?php echo $this->session->flashdata('action_status'); ?>

                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Menu</th>
                                <th>Kategori</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count = 0;
                            foreach ($result as $row) {
                                $count++;
                            ?>
                                <tr>
                                    <td><?php echo $count; ?></td>
                                    <td><?php echo $row->nama_menu; ?></td>
                                    <td><?php echo $row->kategori_nama; ?></td>
                                    <td>
                                        <a href="<?php echo site_url('menu/edit/' . $row->id); ?>" class="btn btn-secondary btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        &nbsp;
                                        <a href="<?php echo site_url('menu/hapus/' . $row->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
