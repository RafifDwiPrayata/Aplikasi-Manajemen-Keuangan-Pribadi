<main>
  <div class="container-fluid">
    <h1 class="mt-4">Form Tambah Menu</h1>
    <ol class="breadcrumb mb-4">
      <li class="breadcrumb-item"><a href="<?php echo site_url('dashboard'); ?>">Dashboard</a></li>
      <li class="breadcrumb-item active">Form Tambah Menu</li>
    </ol>
    <div class="card mb-4">
      <div class="card-body">

        <?php echo validation_errors(); ?>

        <form action="<?php echo site_url('menu/tambah'); ?>" method="post">
  <!-- INPUT Text Nama Menu -->
  <div class="form-group">
    <label for="inputNamaMenu">Nama Menu</label>
    <input type="text" class="form-control" name="menu_nama" id="inputNamaMenu" value="<?php echo set_value('menu_nama'); ?>" autofocus>
  </div>

  <!-- SELECT Kategori -->
  <div class="form-group">
    <label for="inputKategoriNama">Kategori</label>
    <select class="form-control" name="kategori_nama" id="inputKategoriNama">
      <option value="">Pilih Kategori</option>
      <?php foreach ($kategori as $row) { ?>
        <option value="<?php echo $row->kategori_nama; ?>" <?php echo set_select('kategori_nama', $row->kategori_nama); ?>>
          <?php echo $row->kategori_nama; ?>
        </option>
      <?php } ?>
    </select>
  </div>

  <div class="card-footer">
    <button type="submit" class="btn btn-info">Submit</button>
    <a href="<?php echo site_url('menu/index'); ?>" class="btn btn-link float-right"><i class="fas fa-arrow-left"></i> Kembali</a>
  </div>
</form>

      </div>
    </div>
  </div>
</main>
